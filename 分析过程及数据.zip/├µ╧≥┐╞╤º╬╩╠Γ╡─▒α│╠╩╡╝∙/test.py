import csv
dataCSV = open('c:/Users/zhang/Desktop/面向科学问题的编程实践/new.csv', 'w', newline='', encoding='utf-8')
headerCSV = ['comment_id', 'title', 'readcount', 'date', 'user_id', 'reply_count']
writer = csv.DictWriter(dataCSV,headerCSV)
writer.writeheader()