import requests
from bs4 import BeautifulSoup
import multiprocessing
#import SQL
import time
import csv
import random
count_csv = 0

def getHtml(url):#下载网页源代码
    header = {
        "User-Agent":
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:61.0) Gecko/20100101 Firefox/61.0",
    }
    tunnel = "x477.kdltps.com:15818"

# 用户名密码方式
    username = "t11058288076836"
    password = "40ghy5p1"
    proxies = {
        "http": "http://%(user)s:%(pwd)s@%(proxy)s/" % {"user": username, "pwd": password, "proxy": tunnel},
        "https": "http://%(user)s:%(pwd)s@%(proxy)s/" % {"user": username, "pwd": password, "proxy": tunnel}
    } 
    try:
        r = requests.get(url,
                                headers=header,
                                timeout=60,
                                proxies=proxies)
        r.encoding='utf-8'
        #print(r.status_code)
        r.raise_for_status()
        return r.text
    except:
         return getHtml(url)

'''def getDate(commentHtml):#在网页源码中获得评论发表日期，格式：'yyyy-mm-dd'
    #print(1)
    soup = BeautifulSoup(commentHtml, "html.parser")
    tempDate = soup.find("div", {"class": "author-info cl"})
    #print(tempDate)
    if soup.find("div", {"class": "time"})==None:
        return None
    date = soup.find("div", {"class": "time"}).text
    return date[0:11]'''

'''def getLikeCount(commentHtml):#在网页源码中获得特定评论的点赞人数
    soup = BeautifulSoup(commentHtml, "html.parser")
    if soup.find("span", {"class": "likemodule"})==None:
        return None
    likeCount=soup.find("span", {"class": "likemodule"})
    return int(likeCount[1:-1])'''

'''def getUserFans(userHtml):#在网页源码中获得用户粉丝数
            soup = BeautifulSoup(userHtml, "html.parser")
            #print(soup)
            if soup.find("a", {"id": "tafansa"}) == None:
                return None
            if soup.find("a", {"id": "tafansa"}).find("span") == None:
                return None
            fans=soup.find("a", {"id": "tafansa"}).find("span", {"class": "num"})
            return int(fans)'''


def getAndStoreInf(html,share_code):
    soup = BeautifulSoup(html, "html.parser")
    #print(soup)
    contain = soup.find_all("tr", {"class": "listitem"})#获取每条评论节点
    #print (contain)
    #print(contain)
    dataCSV = open('c:/Users/zhang/Desktop/面向科学问题的编程实践/news.csv', 'a', newline='', encoding='utf-8')
    headerCSV = ['comment_id', 'title', 'readcount', 'date', 'user_id', 'reply_count']
    writer = csv.DictWriter(dataCSV,headerCSV)
    for i in contain:
        #print(i)
        try:
            if (i != None) and (i.find("em", {"class": "hinfo"}) == None and i.find("em", {"class": "settop"}) == None and "id" not in i.attrs.keys()):
                #print("OK")
                #content = i.find("td",{"div", {"class": "title"}}).find(a)
                content = i.find("div", {"class": "title"}).find("a")
                #print(content)
                #print(i,content)
                contentUrl="http://guba.eastmoney.com"+content["href"]#内容详情页面
                readcount = i.find("div", {"class": "read"}).get_text()
                replycount = i.find("div", {"class": "reply"}).get_text()
                datecount = i.find("div", {"class": "update"}).get_text()
                datecount = datecount[0:5]
                userUrl = i.find("div", {"class": "author"}).find("a").attrs["href"]
                userId=userUrl[23:]
                userUrl = "https:" + userUrl
                text=content.get_text()#获取评论标题。
                if "caifuhao" in str(contentUrl):
                     continue
                #print(i)
                #print(contentUrl)
                
                commentId=content["href"][-14:-5]
                #print(commentId)
                if contentUrl.__contains__("qa") or contentUrl.__contains__("cfhpl"):#排除问答等内容，只保留用户评论
                    continue
                if userUrl=="http://guba.eastmoney.com/list,jjdt.html":#排除基金动态资讯
                    continue
                comment={"readcount":readcount,"reply_count":replycount,"date":datecount,"title":text}
                writer.writerow(comment)
                
        except:
            continue

def run(data):
        html = getHtml("https://guba.eastmoney.com/list,"+data[0]['share_code']+"_" + str(data[0]['page']) + ".html")
        getAndStoreInf(html,data['share_code'])
        #print("https://guba.eastmoney.com/list,"+data['share_code']+"_" + str(data['page']) + ".html")
        #print(count_csv)

if __name__ == '__main__':
    for i in range(250,1,-1):
        print(i)
        share_code=[]
        share_code.append({'share_code':'002230','page':i})
        run(share_code)
        print('-------sleeping-------')
        time.sleep(random.randint(20,40))
